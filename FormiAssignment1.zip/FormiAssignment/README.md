# Property Search API

A sophisticated Flask-based service designed to locate properties within a 50km radius of any Indian location. The system excels at understanding natural language queries and gracefully handles common location name misspellings.

## Core Capabilities

- 🔍 Intelligent natural language location interpretation
- 🗺️ Comprehensive Indian location geocoding
- ✍️ Smart handling of location name variations and typos
- 📏 Precise 50km radius property matching
- 📊 Distance-optimized result ordering
- ⏱️ Detailed timing analytics

## System Requirements

- Python 3.8 or newer
- Valid Groq API credentials
- Active internet connection for geocoding services

## Setup Instructions

1. Get the codebase:
```bash
git clone <repository-url>
cd <repository-name>
```

2. Set up dependencies:
```bash
pip install -r requirements.txt
```

3. Configure Groq integration:
   - Obtain credentials from [Groq's Console](https://console.groq.com)
   - Insert your API key in `app/utils/location_processor.py`

## Data Import Process

The system requires a SQLite database (`properties.db`) containing property information. Here's how to populate it:

1. Place your property data file (`List_of_Properties_with_Location.pdf`) in the project root

2. Execute the import utility:
```bash
python import_data.py
```

The import process will:
- Initialize a fresh SQLite database
- Parse property details from the PDF
- Extract location coordinates and details
- Populate the database with structured data

Expected PDF content structure:
```
Property Name 1 latitude1 longitude1
Property Address Line 1
Property Address Line 2

Property Name 2 latitude2 longitude2
Property Address Line 1
Property Address Line 2
```

Sample entry:
```
Moustache Udaipur Luxuria 24.57799888 73.68263271
Near Fateh Sagar Lake, Udaipur
Rajasthan, India
```

The import utility handles:
- Property information extraction
- Geographic coordinate parsing
- Address compilation
- Data validation
- Detailed error reporting

Verify successful import through:
1. Console output statistics
2. API endpoint `/api/properties` inspection
3. Direct SQLite database examination

## Project Organization

```
.
├── app/
│   ├── __init__.py
│   ├── models/
│   │   └── property.py
│   ├── routes/
│   │   └── api.py
│   └── utils/
│       └── location_processor.py
├── requirements.txt
├── run.py
└── test_api.py
```

## Running the Service

1. Launch the server:
```bash
python run.py
```

2. Access the API at `http://localhost:5000`

## API Documentation

### GET /api/properties/search
Locate properties near a specified location.

**Query Parameters:**
- `location` (string): Location description in natural language

**Usage Examples:**
```bash
# City search
curl "http://localhost:5000/api/properties/search?location=Udaipur"

# Area-specific search
curl "http://localhost:5000/api/properties/search?location=Bandra West Mumbai"

# Landmark-based search
curl "http://localhost:5000/api/properties/search?location=near Gateway of India"
```

**Response Structure:**
```json
{
    "search_location": {
        "name": "Udaipur",
        "coordinates": [24.5854, 73.7125],
        "resolved_address": "Udaipur, Rajasthan, India"
    },
    "count": 5,
    "properties": [
        {
            "name": "Property Name",
            "distance": 2.5,
            "address": "Property Address",
            "latitude": 24.5854,
            "longitude": 73.7125
        }
    ]
}
```

## Testing Framework

Our comprehensive test suite evaluates various search scenarios:

```bash
python test_api.py
```

Test coverage includes:
1. Basic city name searches (including misspellings)
2. Neighborhood and area searches
3. Landmark-based proximity searches
4. Complex multi-parameter queries

Each test provides:
- Request/response timing metrics
- Location resolution details
- Nearest property rankings
- Distance calculations

## Performance Analytics

The test suite generates detailed metrics:
- API response latency
- Total query processing duration
- Aggregate test execution time
- Per-query timing statistics

## Error Management

The system robustly handles:
- Invalid location queries
- Geocoding service failures
- API timeouts
- Location name variations

## System Boundaries

- Fixed 50km search radius
- India-specific location support
- Geocoding service rate limitations
- Internet connectivity requirement