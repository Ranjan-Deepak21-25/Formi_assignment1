from app import db

class Property(db.Model):
    """Property model representing real estate properties."""
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    address = db.Column(db.String(500))
    
    def to_dict(self):
        """Convert property to dictionary format."""
        return {
            'id': self.id,
            'name': self.name,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'address': self.address
        }
    
    @staticmethod
    def from_dict(property_data):
        """Create property instance from dictionary data."""
        return Property(
            name=property_data.get('name'),
            latitude=property_data.get('latitude'),
            longitude=property_data.get('longitude'),
            address=property_data.get('address')
        ) 