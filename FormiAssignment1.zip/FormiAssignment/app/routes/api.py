from flask import Blueprint, jsonify, request
from app.models.property import Property
from geopy.distance import geodesic
from app.utils.location_processor import LocationProcessor

bp = Blueprint('api', __name__, url_prefix='/api')
location_service = LocationProcessor()

@bp.route('/properties/search', methods=['GET'])
def search_properties():
    try:
        # Get user's location query
        user_query = request.args.get('location')
        if not user_query:
            return jsonify({'error': 'Location query is required'}), 400
            
        # Process location query
        location_name = location_service.extract_location(user_query)
        
        # Get coordinates for the location
        location_data = location_service.get_coordinates(location_name)
        if not location_data:
            return jsonify({
                'error': f'Could not find coordinates for: {location_name}'
            }), 404
            
        # Get all properties from database
        all_properties = Property.query.all()
        
        # Find properties within 50km radius
        nearby_properties = []
        search_point = (location_data['latitude'], location_data['longitude'])
        
        for prop in all_properties:
            prop_point = (prop.latitude, prop.longitude)
            distance_km = geodesic(search_point, prop_point).kilometers
            
            if distance_km <= 50:
                prop_details = prop.to_dict()
                prop_details['distance'] = round(distance_km, 2)
                nearby_properties.append(prop_details)
        
        # Sort properties by distance
        nearby_properties.sort(key=lambda x: x['distance'])
        
        return jsonify({
            'search_location': {
                'name': location_name,
                'coordinates': search_point,
                'resolved_address': location_data['address']
            },
            'count': len(nearby_properties),
            'properties': nearby_properties
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/properties', methods=['GET'])
def get_all_properties():
    all_properties = Property.query.all()
    return jsonify({
        'count': len(all_properties),
        'properties': [prop.to_dict() for prop in all_properties]
    }) 