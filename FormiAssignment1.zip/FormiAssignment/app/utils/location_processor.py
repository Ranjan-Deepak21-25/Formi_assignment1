from groq import Groq
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut
from fuzzywuzzy import process

GROQ_API_KEY = "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"

# List of major Indian cities for matching
CITY_LIST = [
    "Delhi", "Mumbai", "Bangalore", "Kolkata", "Chennai", "Hyderabad", 
    "Ahmedabad", "Pune", "Jaipur", "Udaipur", "Lucknow", "Kanpur", 
    "Nagpur", "Indore", "Thane", "Bhopal", "Visakhapatnam", "Agra"
]

class LocationProcessor:
    def __init__(self):
        self.llm = Groq(api_key=GROQ_API_KEY)
        self.geocoder = Nominatim(user_agent="property_finder")
        
    def correct_city_name(self, location):
        """Fix common spelling mistakes in city names."""
        # Check exact match first
        if location in CITY_LIST:
            return location
            
        # Try fuzzy matching if no exact match
        matched_city, match_score = process.extractOne(location, CITY_LIST)
        if match_score >= 80:  # 80% or higher similarity
            print(f"Corrected '{location}' to '{matched_city}'")
            return matched_city
        return location
        
    def extract_location(self, query):
        """Get location from user query using Groq LLM."""
        try:
            response = self.llm.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": "Extract the location name from user queries. Return only the location."},
                    {"role": "user", "content": f"Extract location from: {query}"}
                ]
            )
            extracted_location = response.choices[0].message.content.strip()
            return self.correct_city_name(extracted_location)
        except Exception as e:
            print(f"LLM error: {str(e)}")
            return self.correct_city_name(query)  # fallback to query with correction
            
    def get_coordinates(self, location_name):
        """Convert location to coordinates using geocoding."""
        try:
            search_text = f"{location_name}, India"
            geocoded_location = self.geocoder.geocode(search_text)
            
            if geocoded_location:
                return {
                    'latitude': geocoded_location.latitude,
                    'longitude': geocoded_location.longitude,
                    'address': geocoded_location.address
                }
            return None
            
        except GeocoderTimedOut:
            print("Geocoding timeout")
            return None
        except Exception as e:
            print(f"Geocoding error: {str(e)}")
            return None 