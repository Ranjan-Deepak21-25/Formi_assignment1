import PyPDF2
from app import create_app, db
from app.models.property import Property
import re

def extract_properties_from_pdf(pdf_path):
    """Extract property data from PDF file."""
    property_list = []
    
    try:
        with open(pdf_path, 'rb') as pdf_file:
            # Create PDF reader
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            # Extract text from all pages
            pdf_text = ""
            for page in pdf_reader.pages:
                pdf_text += page.extract_text()
            
            # Process text line by line
            text_lines = pdf_text.split('\n')
            
            # Pattern for coordinates
            coord_pattern = r'(\d+\.\d+)\s+(\d+\.\d+)'
            
            current_property = {}
            
            for line in text_lines:
                line = line.strip()
                if not line:
                    continue
                
                # Look for coordinates in line
                coord_match = re.search(coord_pattern, line)
                if coord_match:
                    # Save previous property if exists
                    if current_property:
                        property_list.append(current_property)
                    
                    # Extract coordinates
                    lat, lon = coord_match.groups()
                    
                    # Get property name (text before coordinates)
                    property_name = line[:line.find(lat)].strip()
                    
                    # Create new property
                    current_property = {
                        'name': property_name,
                        'latitude': float(lat),
                        'longitude': float(lon),
                        'address': ''
                    }
                elif current_property:
                    # Add line to address
                    current_property['address'] = (current_property['address'] + ' ' + line).strip()
            
            # Add last property
            if current_property:
                property_list.append(current_property)
                
    except Exception as e:
        print(f"PDF reading error: {str(e)}")
        return []
    
    return property_list

def import_properties():
    """Import properties into database."""
    app = create_app()
    with app.app_context():
        try:
            # Read properties from PDF
            properties_data = extract_properties_from_pdf('List_of_Properties_with_Location.pdf')
            
            if not properties_data:
                print("No properties found in PDF!")
                return
            
            # Clear existing data
            Property.query.delete()
            
            # Import properties
            for prop_data in properties_data:
                new_property = Property.from_dict(prop_data)
                db.session.add(new_property)
            
            db.session.commit()
            print(f"Successfully imported {len(properties_data)} properties!")
            
        except Exception as e:
            print(f"Import error: {str(e)}")
            db.session.rollback()

if __name__ == '__main__':
    import_properties() 